Download the source images into this directory from http://www.openjpeg.org/OPJ_Validate_OriginalImages.7z
