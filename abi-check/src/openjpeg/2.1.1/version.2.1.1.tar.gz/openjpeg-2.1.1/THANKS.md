# OpenJPEG THANKS file

Many people have contributed to OpenJPEG by reporting problems, suggesting various improvements,
or submitting actual code. Here is a list of these people. Help me keep
it complete and exempt of errors.

Giuseppe Baruffa
Ben Boeckel
Aaron Boxer
David Burken
Matthieu Darbois
Rex Dieter
Herve Drolon
Antonin Descampe
Francois-Olivier Devaux
Parvatha Elangovan
Jerôme Fimes
Bob Friesenhahn
Kaori Hagihara
Luc Hermitte
Luis Ibanez
David Janssens
Hans Johnson
Callum Lerwick
Sebastien Lugan
Benoit Macq
Mathieu Malaterre
Julien Malik
Arnaud Maye
Vincent Nicolas
Glenn Pearson
Even Rouault
Dzonatas Sol
Winfried Szukalski
Vincent Torri
Yannick Verschueren
Peter Wimmer
